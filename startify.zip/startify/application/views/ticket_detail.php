<link href='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css'>
<link href='https://use.fontawesome.com/releases/v5.7.2/css/all.css'>
<style type="text/css">
    .btngroup .btn {
    -moz-user-select: none;
    -ms-user-select: none;
    -webkit-user-select: none;
    user-select: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    display: inline-block;
    width: auto;
    text-decoration: none;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    border: 1px solid transparent;
    border-radius: 2px;
    padding: 8px 15px;
    background-color: #557b97;
    color: #fff;
    font-family: "Work Sans",sans-serif;
    font-style: normal;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .08em;
    white-space: normal;
    font-size: 14px;
}
.btngroup {
    margin-top: 20px;
}
    .ticketdetail {
    padding: 20px;
}
.ticketdetail {
    max-width: 1000px;
    width: 100%;
    margin: 40px auto;
}

    .left-detail {
        float: left;
        width: 50%;
        line-height: 1.3;
        }

        .form-control {
    border: 1px solid #949494;
    background-color: #fff;
    color: #000;
    max-width: 100%;
    line-height: 1.2;
    border-radius: 2px;
    padding: 10px 10px;
    width: 100%;
}

.right-detail {
    float: right;
    width: 50%;
}

#statusform .form-group {
    margin-top: 20px;
}

.left-detail .col {
    margin-bottom: 10px;
    color: #3d4246;
    font-size: 15px;
}
.left-detail .col strong {
    color: #333;
}
.commentlist {
    border-top: 1px solid #ccc;
    margin-top: 32px;
}
.comment {
    border: 1px solid #ccc;
    padding: 15px;
    margin-bottom: 15px;
    font-family: "Work Sans",sans-serif;
    font-style: normal;
    font-weight: 400;
    line-height: 1.2;
    color: #3d4246;
    font-size: 14px;
    border-radius:3px;
}

.border-line {
    margin: 30px auto;
    border: none;
    height: 1px;
    background: #ccc;
}
.comment h4 {
    display: inline-block;
    margin: 0 0 12px;
    font-family: "Work Sans",sans-serif;
    font-style: normal;
    font-weight: 600;
    line-height: 1.2;
    color: #333;
    text-transform:capitalize;
}

.comment .date {
    font-family: "Work Sans",sans-serif;
    font-style: normal;
    font-weight: 400;
    line-height: 1.2;
    color: #3d4246;
    font-size: 12px;
    padding-left: 8px;
}
.OrderNumber {
    color: #333;
    font-size: 14px;
}

.my-orders-tracking-tittle {
    padding-left: 0 !important;
    padding-right: 0 !important;
    font-size: 22px !important;
    
}
.back-ticket-link {
    float: right;
    font-size: 14px;
}

.back-ticket-link a {
    text-transform: capitalize;
    color: #09243c;
    font-weight: 600;
}
.statuspagetitle
{
    margin-top: 0;
}
.right-detail h4 {
    color: #3d4246;
}
</style>
<?php //echo "<pre>";print_r($ticket_detail); ?>
<div class="container">
    <article class="card ticketdetail">
        
        <header class="card-header my-orders-tracking-tittle"> My Orders / Tracking 
            <div class="back-ticket-link"><a href="http://79d928ff220e.ngrok.io/startify/ticket-listing/" data-abc="true" class="btn btn-info btn-md"> <i class="fa fa-chevron-left"></i> Back to ticket list</a></div>
        </header>
        <div class="card-body ">
            <h6 class="OrderNumber">
                Order ID: <?php echo $ticket_detail[0]['OrderNumber']; ?>
                <?php if($real_orderid != ''){ ?>
                <div class="back-ticket-link">    
                <a target="_blank" data-abc="true" class="btn btn-info btn-md" href="https://ipl2019.myshopify.com/admin/orders/<?php echo $real_orderid; ?>" style="float: right;">Order Detail</a>
                </div>
                <?php }else{ ?>
                    <span style="float: right;color: red;">This order number not exist in shopify store</span>
                <?php }?>

            </h6>
             <hr class="border-line">
           
            <article class="">
                <div class="card-body row ">
                  <div class="left-detail">
                         <div class="col"> <strong>Ticket number: </strong><?php echo $ticket_detail[0]['TicketNumber'];?></div>
                     <div class="col"> <strong>Name: </strong><?php echo $ticket_detail[0]['Name'];?></div>
                    <div class="col"> <strong>Email: </strong><?php echo $ticket_detail[0]['Email'];?></div>
                    <div class="col"> <strong>Phone number: </strong><?php echo $ticket_detail[0]['PhoneNumber'];?></div>
                    <div class="col"> <strong>Return Bank detail: </strong>  <?php echo $ticket_detail[0]['ReturnBankdetail'];?> </div>
                    <div class="col"> <strong>Reason: </strong> <?php echo $ticket_detail[0]['Reason'];?> </div>
                    <div class="col"> <strong>Attachment: </strong>
                    <?php if($ticket_detail[0]['Document'] != ''){ ?>
                     <a target="_blank" href="http://79d928ff220e.ngrok.io/startify/uploads/document/<?php echo $ticket_detail[0]['Document']; ?>">View attachment</a>
                    <?php } ?>
                    </div>
                    <div class="col"> <strong>Current Status: </strong> 
                        <?php  
                            if($ticket_detail[0]['Status'] == '1'){
                                echo "New";
                            }
                            else if($ticket_detail[0]['Status'] == '2'){
                                echo "Return Inprocess";
                            }
                            else if($ticket_detail[0]['Status'] == '3'){
                                echo "Return Done";
                            }
                            else if($ticket_detail[0]['Status'] == '4'){
                                echo "Closed";
                            }
                            else if($ticket_detail[0]['Status'] == '5'){
                                echo "Invalid";
                            }


                        ?>
                        

                     </div>

                 </div>
                 <div class="right-detail">
                   <div class="col">
                        <h4 class="statuspagetitle">Change Status</h4> 
                        <form id="statusform">
                            <input  type="hidden" name="action" value="change_status">
                            <input type="hidden" id="order_id" name="order_id" value="<?php echo $ticket_detail[0]['Id']; ?>">
                            
                            <div class="form-group">
                                <select class="form-control" name="status" id="status">

                                <option>Select Status</option>
                                <?php foreach ($order_status as $key => $statusval) { ?>
                                  <option value="<?php echo $statusval['Id']; ?>" <?php  if($statusval['Id'] == $ticket_detail[0]['Status']){?> selected  <?php }?>><?php echo $statusval['StatusName']; ?></option>
                                <?php } ?>
                               </select>
                            </div>
                            <div class="form-group">
                            
                              <textarea class="form-control" name="comment" id="comment"></textarea>
                            </div>
                            <div class="btngroup"><input type="button" name="submit" class="btn btn-info btn-md" value="Submit" onclick="chnagesstatus()"></div>
                        </form>
                        <div class="commentlist">
                            <h4>Comments</h4>
                            <?php foreach ($ticket_comment as $key => $value) {
                            ?>
                            <div class="comment">
                                <h4><?php echo $value['Username']; ?></h4>
                                <span class="date"><?php 
                                  $orgDate = $value['CreatedDate'];
                            $newDate = date("m-d-Y", strtotime($orgDate));  
                            echo $newDate; 
                        
                                
                            ?></span>
                            <p><?php echo $value['Comment']; ?></p>
                            </div>
                        <?php } ?>
                        </div>
                     </div>
                 </div>  
                </div>
            </article>
            
           </div>
    </article>

    <article class="card ticketdetail">
        
        <header class="card-header my-orders-tracking-tittle"> Order Detail </header>
        <div class="card-body ">
            <?php if(!empty($orders['order'])){?>
                 <div class="left-detail prodcut-detail">
                    <div class="detail-left">
                        <div class="col"> <strong>Prodcut Name: </strong> <?php echo $orders['order']['line_items'][0]['name'];?> </div>
                        <div class="col"> <strong>Order number: </strong><?php echo $orders['order']['id'];?></div>
                        <div class="col"> <strong>Status: </strong><?php echo $orders['order']['financial_status'];?></div>
                    </div>
                    <div class="detail-right">
                        <div class="col"> <strong>Subtotal: </strong><?php echo $orders['order']['subtotal_price'];?></div>
                        <div class="col"> <strong>Tax: </strong><?php echo $orders['order']['total_tax'];?></div>
                        <div class="col totalprice"> <strong>Total Price: </strong>  <?php echo $orders['order']['total_price'];?> </div>
                    </div>
            <?php }else{ ?>
                    <span style="color: red;">This order number not exist in shopify store</span>
                <?php }?>

        </div>
    </article>
</div>
<style type="text/css">
    .left-detail.prodcut-detail {
    width: 100%;
    padding-top: 20px;
}

.prodcut-detail {
    width: 100%;
}

.left-detail {
    float: left;
    width: 50%;
    line-height: 1.3;
}

.prodcut-detail .detail-left {
    float: left;
    width: 50%;
    box-sizing: border-box;
    padding-right: 10px;
}

.prodcut-detail .detail-right {
    float: left;
    width: 50%;
    text-align: right;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
  function chnagesstatus() {
        /*falg to check the data, if there is an error, flag will turn to 1*/
        var flag = 0;
        /*Checking the value of inputs*/
        var status = $('#status').val();
        var comment = $('#comment').val();
        var order_id = $('#order_id').val();
        
        if (status == '' || status == undefined) {
            alert("Select status");
            flag = 1;
        }
    
        if (comment == '' || comment == undefined) {
           alert("Enter comment value");
           flag = 1;
        }
    
        /*if there is no error, go to flag==0 condition*/
        if (flag == 0) 
        {
           $.ajax({
            url: 'http://79d928ff220e.ngrok.io/startify/chnage-status/',
            type: 'POST',
            data: $('#statusform').serialize(),
            success: function(data){
                //alert(data);
               var message_val = JSON.parse(data);
                //alert(message_val.message);
                if(message_val.message == 'success')
                {
                    alert("Status successfully Updated");
                    window.location.href = "http://79d928ff220e.ngrok.io/startify/ticket-detail/?order_id="+order_id;
                }
                else if(message_val.message == 'fial')
                {
                    alert("Status not updated successfully somthing went wrong");
                }
                else if(message_val.message == 'order_id_fail')
                {
                    alert("Order id not found");
                }
                
              }
            });
        } else {
            alert('Something went wrong');
            return false;
        }
    }
</script>


<style type="text/css">
     @import url('https://fonts.googleapis.com/css?family=Open+Sans&display=swap');

 body {
     background-color: #eeeeee;
     font-family: 'Open Sans', serif
 }

 .container {
     margin-top: 50px;
     margin-bottom: 50px
 }

 .card {
     position: relative;
     display: -webkit-box;
     display: -ms-flexbox;
     display: flex;
     -webkit-box-orient: vertical;
     -webkit-box-direction: normal;
     -ms-flex-direction: column;
     flex-direction: column;
     min-width: 0;
     word-wrap: break-word;
     background-color: #fff;
     background-clip: border-box;
     border: 1px solid rgba(0, 0, 0, 0.1);
     border-radius: 0.10rem
 }

 .card-header:first-child {
     border-radius: calc(0.37rem - 1px) calc(0.37rem - 1px) 0 0
 }

 .card-header {
     padding: 0.75rem 1.25rem;
     margin-bottom: 0;
     background-color: #fff;
     border-bottom: 1px solid rgba(0, 0, 0, 0.1)
 }

 .track {
     position: relative;
     background-color: #ddd;
     height: 7px;
     display: -webkit-box;
     display: -ms-flexbox;
     display: flex;
     margin-bottom: 60px;
     margin-top: 50px
 }

 .track .step {
     -webkit-box-flex: 1;
     -ms-flex-positive: 1;
     flex-grow: 1;
     width: 25%;
     margin-top: -18px;
     text-align: center;
     position: relative
 }

 .track .step.active:before {
     background: #FF5722
 }

 .track .step::before {
     height: 7px;
     position: absolute;
     content: "";
     width: 100%;
     left: 0;
     top: 18px
 }

 .track .step.active .icon {
     background: #ee5435;
     color: #fff
 }

 .track .icon {
     display: inline-block;
     width: 40px;
     height: 40px;
     line-height: 40px;
     position: relative;
     border-radius: 100%;
     background: #ddd
 }

 .track .step.active .text {
     font-weight: 400;
     color: #000
 }

 .track .text {
     display: block;
     margin-top: 7px
 }

 .itemside {
     position: relative;
     display: -webkit-box;
     display: -ms-flexbox;
     display: flex;
     width: 100%
 }

 .itemside .aside {
     position: relative;
     -ms-flex-negative: 0;
     flex-shrink: 0
 }

 .img-sm {
     width: 80px;
     height: 80px;
     padding: 7px
 }

 ul.row,
 ul.row-sm {
     list-style: none;
     padding: 0
 }

 .itemside .info {
     padding-left: 15px;
     padding-right: 7px
 }

 .itemside .title {
     display: block;
     margin-bottom: 5px;
     color: #212529
 }

 p {
     margin-top: 0;
     margin-bottom: 1rem
 }

 .btn-warning {
     color: #ffffff;
     background-color: #ee5435;
     border-color: #ee5435;
     border-radius: 1px
 }

 .btn-warning:hover {
     color: #ffffff;
     background-color: #ff2b00;
     border-color: #ff2b00;
     border-radius: 1px
 }

 .totalprice {
    border-top: 1px solid #ccc;
    padding-top: 12px;
    margin-top: 12px;
}
</style>