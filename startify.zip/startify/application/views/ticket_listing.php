<!DOCTYPE html>
<html>
    <head>
        <link href="<?php echo site_url(); ?>assets/css/seaff.css" type="text/css" rel="stylesheet">
        <script src="https://cdn.shopify.com/s/assets/external/app.js"></script>


        <script src='https://code.jquery.com/jquery-1.12.3.js'></script>
        <script src='https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js'></script>
        <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js" charset="utf-8"></script>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.1.0/css/responsive.bootstrap.min.css">
   

        <script type="text/javascript">
            ShopifyApp.init({
                apiKey : '<?php echo $api_key; ?>',
                shopOrigin : '<?php echo 'https://'  . $shop; ?>' 
            });
        </script>
        <script type="text/javascript">
            ShopifyApp.ready(function(){
                ShopifyApp.Bar.initialize({
                buttons: {
                    primary: {
                    label: 'Save',
                    message: 'unicorn_form_submit',
                    loading: true
                    }
                }
                });
            });

            $(document).ready(function(){
              $("#example").DataTable({
                // "sPaginationType": "bootstrap",
              });
            });
        </script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js"></script> 
        <link rel="stylesheet" href="http://79d928ff220e.ngrok.io/startify/assets/css/style.css">


               
    
    </head>
<?php //echo "<pre>";print_r($closed);?>
    <body>
        
<?php 

$t = $total_ticket[0]['total'];
$o_1 = $open_one[0]['total'];
$o_2 = $open_two[0]['total'];
$o_3 = $open_three[0]['total'];
$o_4 = $open_four[0]['total'];
$o_5 = $open_five[0]['total'];
$o_6 = $open_sixe[0]['total'];
$o_7= $open_saven[0]['total'];


$r_1 = $return_inprocess_one[0]['total'];
$r_2 = $return_inprocess_two[0]['total'];
$r_3 = $return_inprocess_three[0]['total'];
$r_4 = $return_inprocess_four[0]['total'];
$r_5 = $return_inprocess_five[0]['total'];
$r_6 = $return_inprocess_sixe[0]['total'];
$r_7 = $return_inprocess_saven[0]['total'];

$d_1 = $return_done_one[0]['total'];
$d_2 = $return_done_two[0]['total'];
$d_3 = $return_done_three[0]['total'];
$d_4 = $return_done_four[0]['total'];
$d_5 = $return_done_five[0]['total'];
$d_6 = $return_done_sixe[0]['total'];
$d_7 = $return_done_saven[0]['total'];

$c_1 = $closed_one[0]['total'];
$c_2 = $closed_two[0]['total'];
$c_3 = $closed_three[0]['total'];
$c_4 = $closed_four[0]['total'];
$c_5 = $closed_five[0]['total'];
$c_6 = $closed_sixe[0]['total'];
$c_7 = $closed_saven[0]['total'];

$i_1 = $invalid_one[0]['total'];
$i_2 = $invalid_two[0]['total'];
$i_3 = $invalid_three[0]['total'];
$i_4 = $invalid_four[0]['total'];
$i_5 = $invalid_five[0]['total'];
$i_6 = $invalid_sixe[0]['total'];
$i_7 = $invalid_saven[0]['total'];


?>
<style type="text/css">
   .wrapper.ticket-main {max-width: 1050px;} 
   .wrapper.ticket-main .left_cart, .wrapper.ticket-main .right_cart {
    border: 1px solid #ccc;
}
    .right_cart {
     float: right;
     width: 48.5%;
    }
    .left_cart {
    float: left;
    width: 48.5%;
}
.wrapper.ticket-main h1 {
    margin-bottom: 30px;
}
.ticket-main #example_length {
    text-align: left;
}
.wrapper.ticket-main h1 {
    margin-bottom: 30px;
    text-align: left;
    border-bottom: 1px solid #ccc;
    padding-bottom: 10px;
    font-size: 30px;
}
.ticket-main #example_paginate .pagination li a {
    margin-top: 10px;
}
.ticket-main #example_info {
    text-align: left;
    font-weight: 600;
}
.ticket-main table.dataTable thead th:after {
    bottom: auto;
    top: 50%;   
    transform: translateY(-50%);
}
.ticket-main table.dataTable thead th {
    line-height: 1.2;
    border-bottom: 0;
    vertical-align: middle;
}
.ticket-main table.dataTable tr td {
    vertical-align: top;
    text-align: left;
}

.ticket-main table.dataTable tr td a {
    margin-top: 0;
}
</style>
<div class="wrapper ticket-main">
          <h1>Ticket chart</h1>
    <div class="left_cart">
        <canvas id="myChart" width="500" height="394"></canvas>
        <script type="text/javascript">
     // Our labels along the x-axis\
     
var total_ticket =  [<?php echo json_encode($t); ?>];
var Open =  [<?php echo json_encode($o_1); ?>,<?php echo json_encode($o_2); ?>,<?php echo json_encode($o_3); ?>,<?php echo json_encode($o_4); ?>,<?php echo json_encode($o_5); ?>,<?php echo json_encode($o_6); ?>,<?php echo json_encode($o_7); ?>];
    /*var return_inprocess = [<?php echo json_encode($r_1); ?>,<?php echo json_encode($r_2); ?>,<?php echo json_encode($r_3); ?>,<?php echo json_encode($r_4); ?>,<?php echo json_encode($r_5); ?>,<?php echo json_encode($r_6); ?>,<?php echo json_encode($r_7); ?>];
var return_done = [<?php echo json_encode($d_1); ?>,<?php echo json_encode($d_2); ?>,<?php echo json_encode($d_3); ?>,<?php echo json_encode($d_4); ?>,<?php echo json_encode($d_5); ?>,<?php echo json_encode($d_6); ?>,<?php echo json_encode($d_7); ?>];
var closed_ticket = [<?php echo json_encode($c_1); ?>,<?php echo json_encode($c_2); ?>,<?php echo json_encode($c_3); ?>,<?php echo json_encode($c_4); ?>,<?php echo json_encode($c_5); ?>,<?php echo json_encode($c_6); ?>,<?php echo json_encode($c_7); ?>];
var invalid = [<?php echo json_encode($i_1); ?>,<?php echo json_encode($i_2); ?>,<?php echo json_encode($i_3); ?>,<?php echo json_encode($i_4); ?>,<?php echo json_encode($i_5); ?>,<?php echo json_encode($i_6); ?>,<?php echo json_encode($i_7); ?>];

*/
  var ctx = document.getElementById('myChart').getContext('2d');
  var myChart = new Chart(ctx, {
  type: 'line',
  data: {
  labels: ["Thursday", "Friday", "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday"],


  datasets: [
      { 
        data: total_ticket,
        label: "Total ticket",
        borderColor: "#A9A9A9",
        backgroundColor: "#A9A9A9",
        fill: false,
        lineTension:0,
        pointRadius: 5
      },
      { 
        data: Open,
        label: "Open",
        borderColor: "#7bb6dd",
        backgroundColor: "#7bb6dd",
        fill: false,
        lineTension:0,
        pointRadius: 5
      }
      
      
    ]
  }
});
 </script>


    </div>
    <div class="right_cart">
        <script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>


 <script type="text/javascript">

var o = <?php echo $open[0]['total']; ?>;
var r = <?php echo $return_inprocess[0]['total']; ?>;
var d = <?php echo $return_done[0]['total']; ?>;
var c = <?php echo $closed[0]['total']; ?>;
var i = <?php echo $invalid[0]['total']; ?>;

window.onload = function () {
    var chart1 = new CanvasJS.Chart("chartContainer",
    {
        title:{
            text: ""
        },
        legend: {
            maxWidth: 350,
            itemWidth: 120
        },
        data: [
        {
            type: "pie",
            showInLegend: true,
            legendText: "{indexLabel}",
            dataPoints: [
                { y: o, indexLabel: "Open" },
                { y: i, indexLabel: "Invalid" },
                { y: d, indexLabel: "Return done" },
                { y: r, indexLabel: "Return inprocess"},
                { y: c, indexLabel: "Closed" },
            ]
        }
        ]
    });
    chart1.render();
}


</script>
        <div id="chartContainer" style="height: 400px; width: 100%;"></div>
    </div>
<div style="clear: both;"> </div>          
</div>
<div style="clear: both;"> </div>
        <div id="wrap">
          <div class="wrapper ticket-main">
            <h1>Ticket Listing</h1>
                
                     <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>

            <tr>
                <th>Created date</th>
                <th>Ticket number</th>
                <th>Order number</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone number</th>
                <th>Return bank detail</th>
                <th>Reason</th>
                <th>Attachment</th>
                <th>Current status</th>
                <th>Action</th>
            </tr>

        </thead>

        <tbody>
            <?php foreach ($results as $key => $value) {
                //echo "<pre>";print_r($value);die;
                ?>
                <tr>    
                    <td>
                        <?php 
                            $orgDate = $value['CreatedDate'];
                            $newDate = date("m-d-Y", strtotime($orgDate));  
                            echo $newDate; 
                        ?>
                    </td>
                    <td><?php echo $value['TicketNumber']; ?></td>
                    <td><a href="http://79d928ff220e.ngrok.io/startify/ticket-detail/?order_id=<?php echo $value['Id']; ?>"><?php echo $value['OrderNumber']; ?></a></td>
                    <td><?php echo $value['Name']; ?></td>
                    <td><?php echo $value['Email']; ?></td>
                    <td><?php echo $value['PhoneNumber']; ?></td>
                    <td><?php echo $value['ReturnBankdetail']; ?></td>
                    <td><?php echo $value['Reason']; ?></td>
                    <td><?php if($value['Document'] != ''){?><a target="_blank" href="http://79d928ff220e.ngrok.io/startify/uploads/document/<?php echo $value['Document']; ?>">View attachment</a><?php } ?></td>
                    <td>
                        <?php  
                            if($value['Status'] == '1'){
                                echo "New";
                            }
                            else if($value['Status'] == '2'){
                                echo "Return Inprocess";
                            }
                            else if($value['Status'] == '3'){
                                echo "Return Done";
                            }
                            else if($value['Status'] == '4'){
                                echo "Closed";
                            }
                            else if($value['Status'] == '5'){
                                echo "Invalid";
                            }


                        ?>
                        
                    </td>
                    <td>
                        <a href="http://79d928ff220e.ngrok.io/startify/edit-ticket/?order_id=<?php echo $value['Id']; ?>">Edit</a>
                    </td>
                    <!--<td>
                        <form id="statusform">
                            <input type="hidden" name="action" value="change_status">
                            <input type="hidden" name="order_id" value="<?php echo $value['Id']; ?>">
                            
                            <select name="status" id="status">
                                <option>Select Status</option>
                                <?php foreach ($order_status as $key => $statusval) { ?>
                                  <option value="<?php echo $statusval['Id']; ?>" <?php  if($statusval['Id'] == $value['Status']){?> selected  <?php }?>><?php echo $statusval['StatusName']; ?></option>
                                <?php } ?>
                            </select>
                            <textarea name="comment" id="comment"></textarea>
                            <input type="button" name="submit" class="btn btn-info btn-md" value="Add Status" onclick="chnagesstatus()">
                        </form>
                    </td> -->
                </tr>
            <?php } ?>
            
        </tbody>

    </table>
</div>
</div>
    </body>

</html> 

