<?php 
 
 class  Ccdweb_model extends CI_Model {

 	 public function __construct(){
          
        $this->load->database();
        $this->load->helper( 'db' );
	 }


	function total_ticket_data()
    {
    	//SELECT * FROM items WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 WEEK);
    	$this->db->select('count(*) as total');
		$this->db->from('return_order');
		$result = $this->db->get();
		$res = $result->result_array();
        return $res;


    }

    function weekly_data($status,$day)
    {
    	//SELECT * FROM items WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 WEEK);
    	$this->db->select('count(*) as total');
		$this->db->from('return_order');
		$this->db->where('Status', $status);
        $this->db->where('CreatedDate BETWEEN DATE_SUB(NOW(), INTERVAL '.$day.' DAY) AND NOW()');
		$result = $this->db->get();
		$res = $result->result_array();
        return $res;
	}


    function weeklyall_data($status)
    {
    	//SELECT * FROM items WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 WEEK);
    	$this->db->select('count(*) as total');
		$this->db->from('return_order');
		$this->db->where('Status', $status);
        //$this->db->where('CreatedDate BETWEEN DATE_SUB(NOW(), INTERVAL 7 DAY) AND NOW()');
		$result = $this->db->get();
		$res = $result->result_array();
        return $res;


    }


    function validate($user, $pass)
    {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('password', $pass);
        $this->db->where('username', $user);
        $query = $this->db->get();
        $res = $query->result();
        return $res;
    }


  function search($keyword)
  {
	 $this->db->like('Seo_title',$keyword);
	 $query  = $this->db->get('service_seo');
	 return $query->result_array();

	 //return $query->result();
  }


   function sendMail1()
   {
  	   //Load email library
   	$this->load->library('email');
                            
		$config = array(
                                'protocol'  => 'smtp',
                                'smtp_host' => 'ssl://smtp.googlemail.com',
                                'smtp_port' => 465,
                                'smtp_user' => 'raj.perception@gmail.com',
                                'smtp_pass' => 'A1G915now!',
                                'mailtype'  => 'html',
                                'charset'   => 'utf-8',
                                
                            );
                            $this->email->initialize($config);
        
                            $this->email->set_newline("\r\n");
                            $this->email->from($from);
                            $this->email->to($to);
                            $this->email->subject($subject);
                            $this->email->message($message);

                            if ($this->email->send()) 
                            {
                                echo 'Email has been sent successfully';
                            } 
                            else 
                            {
                                show_error($this->email->print_debugger());
                            }
  }

  public function sendMail($to=null,$fromemail=null,$subject=null,$message=null)
  {
  		 $header = "From:Contact to shopify <".$fromemail.">\r\n";
         $header .= "Cc:shivrajsingh532@gmail.com \r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
         $emailhtml = '';
         $retval = mail ($to,$subject,$emailhtml,$header);
         
         
         if($retval == true)
	     {
	       return 1;
	     }
	     else
	     {
	     	return 0;
	     }

    

		
  }

  public function GetCountfromtable($table=null,$data=null){	
			
			$count = $this->db->select('COUNT(*) AS Count')->from($table)->where($data)->get()->row();
			return $count;
			
		}


   
  public function GetLastIdFromTable($orderbyid=null,$table=null){	

			$last_row=$this->db->select('*')->order_by($orderbyid,"DESC")->limit(1)->get($table)->row();
			//$response = $last_row->result_array();
			//return $response;
		    return array('ID'=>$last_row->$orderbyid);

			
    }


    public function counts($tbl_name=null,$where=null,$limit=null,$columns="*",$join=null,$order=null,$group_by=null)
	{


		$this->db->select($columns);
		$this->db->from($tbl_name);

	    if($join!=null)

	    {

	    	foreach ($join as $key => $j) {

	    		$this->db->join($j["table_name"],$j["condition"],$j["type"]);

	    	}

	    }

	    if($where!=null)

	    	$this->db->where($where);

	    if($limit!=null)

	    {

	    	if(is_numeric($limit))

	    	{

	    		$this->db->limit($limit);

	    	}

	    	else

	    	{

	    		$this->db->limit($limit['total'],$limit['from']);

	    	}

	    }

	    if(!empty($group_by))

	    {

	    	$this->db->group_by($group_by);

	    }

	    if($order!=null)

	    {

	    	$this->db->order_by($order);

	    }

	    $query = $this->db->get();
	    //echo $this->db->last_query();
	    return $query->num_rows();

	}


	public function saveuser($tbl_name=null,$data=null)
	{

		try

		{

			$this->db->insert($tbl_name,$data);
			$insert_id = $this->db->insert_id();
			
			return $insert_id;

		}

		catch(Exception $e)

		{

			return 0;

		}

	}


    public function insertdata($tbl_name=null,$data=null)
	{

		try

		{

			$this->db->insert($tbl_name,$data);
			
			return 1;

		}

		catch(Exception $e)

		{

			return 0;

		}

	}

	public function bachinsertdata($tbl_name=null,$data=null)
	{

		try

		{

			$this->db->insert_batch($tbl_name,$data);

			return 1;

		}

		catch(Exception $e)

		{

			return 0;

		}



	}



    public function Getdatafromtable($tbl_name=null,$where=null,$limit=null,$columns="*",$join=null,$order=null,$group_by=null)
	{

	    $this->db->select($columns);
	    //$this->db->distinct($columns);
	    $this->db->from($tbl_name);

	    if($join!=null)
		{

	    	foreach ($join as $key => $j) {

	    		$this->db->join($j["table_name"],$j["condition"],$j["type"]);

	    	}

	    }

	    if($where!=null)

	    	$this->db->where($where);

	    if($limit!=null)
		{

	    	if(is_numeric($limit))
			{

	    		$this->db->limit($limit);

	    	}
			else
			{

	    		$this->db->limit($limit['total'],$limit['from']);

	    	}

	    }

	    if(!empty($group_by))

	    {

	    	$this->db->group_by($group_by);

	    }

	    if($order!=null)

	    {

	    	$this->db->order_by($order);

	    }

	    $query = $this->db->get();
        //echo $this->db->last_query();
	    return $query->result();
	    //result_array

	}


	public function getalldata($tbl_name=null,$where=null,$limit=null,$columns="*",$join=null,$order=null,$group_by=null)
	{

	    $this->db->select($columns);
	    //$this->db->distinct($columns);
	    $this->db->from($tbl_name);

	    if($join!=null)
		{

	    	foreach ($join as $key => $j) {

	    		$this->db->join($j["table_name"],$j["condition"],$j["type"]);

	    	}

	    }

	    if($where!=null)

	    	$this->db->where($where);

	    if($limit!=null)
		{

	    	if(is_numeric($limit))
			{

	    		$this->db->limit($limit);

	    	}
			else
			{

	    		$this->db->limit($limit['total'],$limit['from']);

	    	}

	    }

	    if(!empty($group_by))

	    {

	    	$this->db->group_by($group_by);

	    }

	    if($order!=null)

	    {

	    	$this->db->order_by($order);

	    }

	    $query = $this->db->get();
        //echo $this->db->last_query();
	    return $query->result_array();
	    //result_array

	}


	public function update($tbl_name=null,$where=null,$data=null,$where_in=null)
	{

		try

		{

			if($where!=null)

			{

				$this->db->where($where);

			}

			if($where_in!=null)

			{

				$this->db->where_in($where_in['from'],$where_in['arraylist']);

			}

			$this->db->update($tbl_name,$data);
			//echo $this->db->last_query();
			return 1;

		}

		catch(Exception $e)

		{

			return 0;

		}

	}

	public function delete($tbl_name=null,$where=null,$data=null)
	{

		try

		{

			if($where!=null)

			{

				$this->db->where($where);

			}

			$this->db->delete($tbl_name);

			return 1;

		}

		catch(Exception $e)

		{

			return 0;

		}

	}

	function __destruct()
	{

        // parent::__destruct();

        $this->db->close();

    }

    public function searchLike($table_name,$where = null,$where_like_array,$columns = '*',$join=null,$order_by = null,$limit = null)
	{
		$this->db->select($columns);
		$this->db->distinct($columns);
		$this->db->from($table_name);
	    if ($where!=null) {
	    	foreach ($where as $key => $value) {
		    	$this->db->where($key,$value);
		    }	
	    }

	    /*foreach ($where_like_array as $key => $value) {

	    	$likevar = $key." "."LIKE "."%".$value."%";
	    	$this->db->where($likevar);
	    }*/

	    foreach ($where_like_array as $key => $value) {
	    	$this->db->like($key,$value,'after');
	    }

	    if ($order_by != null)
	    	$this->db->order_by($order_by);
	    if ($limit!=null) {
	    	if(is_numeric($limit))
	    		$this->db->limit($limit);
	    	else
	    		$this->db->limit($limit['total'],$limit['from']);
	    }
	    if($join!=null) {
	    	foreach ($join as $key => $j) {
	    		$this->db->join($j["table_name"],$j["condition"],$j["type"]);
	    	}
	    }
	    $query = $this->db->get();
	    //echo $this->db->last_query(); 

	    return $query->result();
	}
	public function searchajax($table_name,$where=null,$where_like_array,$columns = '*',$join=null,$order_by = null,$limit = null)
	{
		$this->db->select($columns);
	    $this->db->from($table_name);
	    if($where!=null)
	    {
	    	$this->db->where($where);
	    }
	    foreach ($where_like_array as $key => $value) {
	    	$this->db->like($key,$value,'after');
	    }
	    if ($order_by != null)
	    	$this->db->order_by($order_by);
	    if ($limit!=null) {
	    	if(is_numeric($limit))
	    		$this->db->limit($limit);
	    	else
	    		$this->db->limit($limit['total'],$limit['from']);
	    }
	    if($join!=null) {
	    	foreach ($join as $key => $j) {
	    		$this->db->join($j["table_name"],$j["condition"],$j["type"]);
	    	}
	    }
	    $query = $this->db->get();
	    // echo $this->db->last_query(); 

	    return $query->result();
	}

	// Read data using username and password
public function login($data) {

	$condition = "Username =" . "'" . $data['username'] . "' AND " . "Password =" . "'" . $data['password'] . "'";
	$this->db->select('*');
	$this->db->from('justphoneme_users');
	$this->db->where($condition);
	$this->db->limit(1);
	$query = $this->db->get();

	if ($query->num_rows() == 1) {
	return true;
	} else {
	return false;
	}
}

// Read data from database to show data in admin page
public function read_user_information($username) {

	$condition = "Username =" . "'" . $username . "'";
	$this->db->select('*');
	$this->db->from('justphoneme_users');
	$this->db->where($condition);
	$this->db->limit(1);
	$query = $this->db->get();

	if ($query->num_rows() == 1) {
	return $query->result();
	} else {
	return false;
	}
}



}
