<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// ------------------------------------------------------------------------

if ( ! function_exists( 'printr' ) ) {
	function printr ( $var, $isExit = 0 ) {
		if ( is_array( $var ) ) {
			echo '<pre>';
			print_r( $var );
			echo '</pre>';
		} else {
			echo "<br />" . $var . "<br />";
		}

		if ( $isExit === 1 ) {
			exit();
		}
	}
}

function array_column_recursive ( array $haystack, $needle ) {
    $found = [];

    array_walk_recursive( $haystack, function ( $value, $key ) use ( &$found, $needle ) {
        if ( $key == $needle ) {
            $found[] = $value;
        }
    } );

    return $found;
}

function compressImg ( $source, $destination = FALSE, $quality = 60 ) {
	//echo "$source, $quality, $destination<br />";
	//copy( $source, $destination );

	if ( $destination === FALSE ) {
		$destination = $source;
		chmod( $source, 0777 );
	}

	$mime = substr( $source, strrpos( $source, '.' ) + 1 );
	list( $width, $height ) = getimagesize( $source );

	if ( $mime == 'jpg' ) {
		$quality = $quality + 10;
	}

	$widthNew = $width * $quality / 100;
	$heightNew = $height * $quality / 100;

	$image_p = imagecreatetruecolor( $widthNew, $heightNew );
	$image = '';

	if ( $mime == 'jpg' ) {
		$image = imagecreatefromjpeg( $source );
	} else if ( $mime == 'gif' ) {
		$image = imagecreatefromgif( $source );
	} elseif ( $mime == 'png' ) {
		$image = imagecreatefrompng($source);
	}

	//if ( $image != '' ) {
		imagecopyresampled( $image_p, $image, 0, 0, 0, 0, $widthNew, $heightNew, $width, $height );

		if ( $mime == 'jpg' ) {
			imagejpeg( $image_p, $destination, $quality );
		} else if ( $mime == 'gif' ) {
			imagegif( $image_p, $destination );
		} elseif ( $mime == 'png' ) {
			imagepng( $image_p, $destination, $quality / 10, PNG_ALL_FILTERS );
		}
	//}

	return $destination;
}


// ------------------------------------------------------------------------

if ( ! function_exists( 'getIcon' ) ) {
	function getIcon ( $key, $color = '#343A40', $size = 24 ) {
		$icon = array(
			'wifi' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><g class="svg-color--primary" fill="{color}"><path d="M12.1 5C8.2 5 4.7 6.6 2.2 9.1l.7.7C5.3 7.5 8.5 6 12.1 6s6.8 1.5 9.2 3.8l.7-.7C19.5 6.6 16 5 12.1 5z"/><path d="M4.3 11.2l.7.7C6.8 10.1 9.3 9 12.1 9s5.3 1.1 7.1 2.9l.7-.7c-2-2-4.7-3.2-7.8-3.2s-5.8 1.2-7.8 3.2z"/><path d="M6.5 13.4l.6.6c1.3-1.3 3-2 5-2s3.7.8 5 2l.7-.7c-1.4-1.5-3.4-2.4-5.6-2.4s-4.3 1-5.7 2.5zM8.6 15.5l.7.7c.7-.7 1.7-1.2 2.8-1.2s2.1.5 2.8 1.2l.7-.7c-.9-.9-2.2-1.5-3.5-1.5s-2.6.6-3.5 1.5z"/><circle cx="12.1" cy="18" r="1"/></g></svg>',
			'pool' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><g class="svg-color--primary" fill="{color}"><path d="M16.2 16.1c.2.2.5.2.7 0 .2-.2.2-.5 0-.7-1.2-1.1-2.5-1.1-3.7 0-.8.8-1.5.8-2.3 0-1.2-1.2-2.5-1.2-3.7 0-.2.2-.2.5 0 .7s.5.2.7 0c.8-.8 1.5-.8 2.3 0 .6.6 1.2.9 1.9.9.6 0 1.2-.3 1.8-.9.7-.8 1.4-.8 2.3 0zM10.1 18.4c-.8.8-1.5.8-2.3 0-1.2-1.2-2.5-1.2-3.7 0-.2.2-.2.5 0 .7s.5.2.7 0c.8-.8 1.5-.8 2.3 0 .7.6 1.3.9 1.9.9.6 0 1.2-.3 1.8-.9.2-.2.2-.5 0-.7-.1-.2-.5-.2-.7 0zM19.8 18.4c-1.2-1.1-2.5-1.1-3.7 0-.8.8-1.5.8-2.3 0-.2-.2-.5-.2-.7 0-.2.2-.2.5 0 .7.6.6 1.2.9 1.9.9.6 0 1.2-.3 1.8-.9.8-.8 1.5-.8 2.3 0 .2.2.5.2.7 0 .3-.2.2-.5 0-.7zM7.5 14c.3 0 .5-.2.5-.5V12h7v1.5c0 .3.2.5.5.5s.5-.2.5-.5v-9c0-.3.2-.5.5-.5s.5.2.5.5v2c0 .3.2.5.5.5s.5-.2.5-.5v-2c0-.8-.7-1.5-1.5-1.5S15 3.7 15 4.5V8H8V4.5c0-.3.2-.5.5-.5s.5.2.5.5v2c0 .3.2.5.5.5s.5-.2.5-.5v-2C10 3.7 9.3 3 8.5 3S7 3.7 7 4.5v9c0 .3.2.5.5.5zM8 9h7v2H8V9z"/></g></svg>',
			'parking' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><g class="svg-color--primary" fill="{color}"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 19c-5 0-9-4-9-9s4-9 9-9 9 4 9 9-4 9-9 9z"/><path d="M13 5H9.5c-.3 0-.5.2-.5.5v12.9c0 .4.2.6.5.6s.5-.2.5-.5V13h3c2.2 0 4-1.8 4-4s-1.8-4-4-4zm0 7h-3V6h3c1.7 0 3 1.3 3 3s-1.3 3-3 3z"/></g></svg>',
			'pets' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><g class="svg-color--primary" fill="{color}"><path d="M12 11c-3.5 0-6 3-6 7.2 0 1 0 2.8 1.8 2.8.6 0 1.3-.4 2-.8s1.6-1 2.3-1c.7 0 1.6.5 2.3 1 .7.4 1.4.8 2 .8 1.7 0 1.7-1.7 1.7-2.8C18 14 15.5 11 12 11zm4.3 9c-.9 0-2.6-1.8-4.3-1.8S8.6 20 7.8 20c-.6 0-.8-.2-.8-1.8 0-4 2.2-6.2 5-6.2s5 2.2 5 6.2c0 1.6-.2 1.8-.7 1.8zM14.3 9.9c.2 0 .3.1.5.1 1.2 0 2.3-1 2.6-2.4.4-1.6-.4-3.2-1.7-3.5-.2 0-.3-.1-.5-.1-1.2 0-2.3 1-2.6 2.4-.4 1.7.4 3.2 1.7 3.5zm-.7-3.2c.2-1 .9-1.6 1.7-1.6h.3c.8.2 1.2 1.2 1 2.3-.2 1-.9 1.6-1.7 1.6h-.3c-.8-.2-1.3-1.3-1-2.3zM9.2 10h.4c.6-.1 1.1-.5 1.4-1 .4-.7.6-1.6.4-2.4-.3-1.4-1.4-2.5-2.6-2.5h-.4c-.5.1-1.1.5-1.4 1-.4.7-.6 1.5-.4 2.4C6.9 9 8 10 9.2 10zm-.6-4.9h.2c.7 0 1.4.7 1.6 1.7.2 1.1-.3 2.1-1.1 2.2h-.1c-.7 0-1.5-.7-1.6-1.7-.3-1.1.2-2.1 1-2.2zM7.1 12.2c.2-.8.1-1.7-.3-2.5C6.3 8.7 5.3 8 4.2 8c-.4 0-.7.1-1 .3-.5.3-.9.8-1.1 1.4-.2.8-.1 1.7.3 2.5.6 1 1.6 1.6 2.6 1.6.4 0 .7-.1 1-.3.6-.2 1-.7 1.1-1.3zm-1.5.5c-.2.1-.4.1-.6.1-.6 0-1.3-.4-1.7-1.2-.5-1-.4-2.1.4-2.5.2 0 .3-.1.5-.1.7 0 1.4.5 1.8 1.2.5 1 .3 2.1-.4 2.5zM22.1 9.7c-.2-.6-.6-1.1-1.1-1.4-.3-.2-.6-.3-1-.3-1 0-2 .7-2.6 1.7-.4.8-.5 1.7-.3 2.5.2.6.6 1.1 1.1 1.4.3.2.7.3 1 .3 1 0 2-.7 2.6-1.7.5-.9.6-1.8.3-2.5zM21 11.6c-.4.7-1.1 1.2-1.7 1.2-.2 0-.4 0-.6-.1-.7-.4-.9-1.5-.4-2.5.4-.7 1.1-1.2 1.7-1.2.2 0 .4 0 .6.1.7.5.9 1.6.4 2.5z"/></g></svg>',
			'ac' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><path class="svg-color--primary" fill="{color}" d="M21.345 12.736l-4.766 1.228L13.04 12l3.538-1.963 4.766 1.228c.277.07.563-.087.637-.354.075-.266-.09-.54-.367-.61l-3.76-.97 2.967-1.646c.25-.14.334-.445.19-.684-.143-.24-.46-.32-.71-.183l-2.967 1.646 1.008-3.615c.038-.133.016-.27-.05-.38-.068-.11-.178-.196-.317-.232-.277-.07-.563.087-.637.354L16.06 9.17l-3.54 1.964V7.207l3.49-3.354c.203-.195.203-.512 0-.707-.203-.195-.532-.195-.736 0L12.52 5.793V2.5c0-.276-.232-.5-.52-.5s-.52.224-.52.5v3.293L8.726 3.146c-.203-.195-.532-.195-.736 0s-.203.512 0 .707l3.49 3.354v3.927L7.94 9.17 6.665 4.59c-.074-.267-.36-.425-.637-.354-.277.072-.442.346-.368.612l1.007 3.615L3.7 6.817c-.25-.138-.567-.056-.71.183-.144.24-.06.545.19.683L6.147 9.33l-3.76.97c-.278.07-.443.344-.37.61.076.268.36.426.638.355l4.766-1.228L10.96 12l-3.538 1.963-4.766-1.228c-.277-.07-.562.087-.637.354-.075.266.09.54.367.61l3.76.97-2.967 1.647c-.25.138-.334.444-.19.683.144.24.462.32.71.183l2.968-1.646-1.008 3.615c-.074.267.09.54.368.612.278.07.563-.087.637-.354l1.277-4.58 3.538-1.964v3.927l-3.49 3.354c-.202.195-.202.512 0 .707s.533.195.737 0l2.753-2.646V21.5c0 .276.233.5.52.5s.52-.224.52-.5v-3.293l2.753 2.646c.102.098.235.147.368.147.134 0 .267-.05.37-.146.202-.195.202-.512 0-.707l-3.49-3.354v-3.927l3.538 1.963 1.277 4.58c.074.267.36.425.637.354.277-.072.442-.346.368-.612l-1.008-3.615 2.967 1.646c.248.138.565.056.71-.183.143-.24.058-.545-.19-.683L17.85 14.67l3.76-.968c.14-.036.25-.122.317-.232.066-.11.088-.246.05-.38-.072-.267-.358-.425-.635-.354z"/></svg>',
			'restra' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><g class="svg-color--primary" fill="{color}"><path d="M4.71 4.29c-.32-.32-.8-.38-1.18-.17-.07.03-.15.08-.2.13l-.04.04c-.37.37-.39.95-.06 1.35l7.07 8.48c.04.05.09.1.14.14.16.13.37.21.58.22.28.01.56-.09.76-.29l.7-.71 6.66 6.37c.2.2.51.2.71 0 .2-.2.2-.51 0-.71L4.71 4.29zM4 5l7.78 7.77-.71.71L4 5zM9.08 14.22l-4.93 4.94c-.2.19-.2.51 0 .69.18.2.5.2.69 0l4.89-4.89-.21-.21-.44-.53zM20.86 5.93c-.2-.19-.5-.19-.7 0l-3.48 3.48c-.2.2-.5.2-.69 0-.2-.2-.2-.5 0-.7l3.47-3.48c.2-.19.2-.5 0-.69-.19-.2-.5-.2-.69 0l-3.48 3.47c-.2.2-.5.2-.7 0-.2-.19-.2-.49 0-.69l3.48-3.48c.19-.2.19-.5 0-.7-.19-.19-.5-.19-.7 0l-3.82 3.83c-.77.77-.77 2.02 0 2.78l-.91.91.7.68.01.01.9-.9c.76.77 2.01.77 2.78 0l3.83-3.82c.19-.2.19-.51 0-.7z"/></g></svg>',
			'bar' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><g class="svg-color--primary" fill="{color}"><path d="M12.7 14.7l6-6c.3-.3.4-.7.2-1.1-.1-.4-.5-.6-.9-.6h-7.2L10 4.4c0-.3-.2-.4-.4-.4H6c-.3 0-.5.2-.5.5s.2.5.5.5h3.2l.6 2H6c-.4 0-.8.2-.9.6-.2.4-.1.8.2 1.1l6 6c.1.1.1.1.2.1V20H9c-.3 0-.5.2-.5.5s.2.5.5.5h6c.3 0 .5-.2.5-.5s-.2-.5-.5-.5h-2.5v-5.2c.1 0 .1 0 .2-.1zM6 8h4.1l.9 3.3c.1.2.3.4.5.4h.1c.3-.1.4-.4.3-.6l-.9-3h7l-6 6L6 8z"/><circle cx="14" cy="10" r="1"/></g></svg>',
			'gym' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><path class="svg-color--primary" fill="{color}" d="M21.5 12H20V9.5c0-.83-.67-1.5-1.5-1.5-.18 0-.34.03-.5.09V7.5c0-.83-.67-1.5-1.5-1.5S15 6.67 15 7.5V12H9V7.5C9 6.67 8.33 6 7.5 6S6 6.67 6 7.5v.59C5.84 8.03 5.68 8 5.5 8 4.67 8 4 8.67 4 9.5V12H2.5c-.28 0-.5.22-.5.5s.22.5.5.5H4v2.5c0 .83.67 1.5 1.5 1.5.2 0 .39-.04.56-.11.16.64.74 1.11 1.44 1.11.83 0 1.5-.67 1.5-1.5V13h6v3.5c0 .83.67 1.5 1.5 1.5.7 0 1.28-.47 1.44-1.11.17.07.36.11.56.11.83 0 1.5-.67 1.5-1.5V13h1.5c.28 0 .5-.22.5-.5s-.22-.5-.5-.5zm-16 4c-.28 0-.5-.22-.5-.5v-6c0-.28.22-.5.5-.5s.5.22.5.5v6c0 .28-.22.5-.5.5zm2.5.5c0 .28-.22.5-.5.5s-.5-.22-.5-.5v-9c0-.28.22-.5.5-.5s.5.22.5.5v9zm9 0c0 .28-.22.5-.5.5s-.5-.22-.5-.5v-9c0-.28.22-.5.5-.5s.5.22.5.5v9zm2-1c0 .28-.22.5-.5.5s-.5-.22-.5-.5v-6c0-.28.22-.5.5-.5s.5.22.5.5v6z"/></svg>',
			'breakfast' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><g class="svg-color--primary" fill="{color}"><path d="M17.8 10.1l.2-.9c.1-.3 0-.6-.2-.8-.2-.3-.5-.4-.8-.4H5c-.3 0-.6.1-.8.4-.2.2-.2.5-.2.8l2 10c.1.5.5.8 1 .8h8c.5 0 .9-.3 1-.8l.3-1.3c.2.1.4.1.7.1 2.2 0 4-1.8 4-4 0-1.9-1.4-3.5-3.2-3.9zM15 19H7L5 9h12l-2 10zm2-2h-.6l1.2-5.9c1.4.3 2.4 1.5 2.4 2.9 0 1.6-1.4 3-3 3zM18.5 21h-15c-.3 0-.5.2-.5.5s.2.5.5.5h15c.3 0 .5-.2.5-.5s-.2-.5-.5-.5zM6.9 5.7c.1.8.7 1.2.8 1.2.1.1.2.1.3.1.2 0 .3-.1.4-.2.2-.2.1-.5-.1-.7 0 0-.3-.2-.3-.5s.2-.6.4-.8c.4-.5.6-1 .6-1.5-.1-.8-.7-1.2-.8-1.2-.2-.2-.5-.1-.7.1-.1.3 0 .6.2.7 0 0 .3.2.3.5s-.2.6-.4.7c-.5.6-.7 1.1-.7 1.6zM9.9 5.7c.1.7.7 1.2.8 1.2.1.1.2.1.3.1.2 0 .3-.1.4-.2.2-.2.1-.5-.1-.7 0 0-.3-.2-.3-.5s.2-.6.4-.8c.5-.5.7-1 .7-1.6-.1-.7-.7-1.2-.8-1.2-.3-.1-.6 0-.8.2-.2.2-.1.5.1.7 0 0 .3.2.3.5s-.2.6-.4.8c-.4.5-.6 1-.6 1.5zM12.9 5.7c.1.7.7 1.2.8 1.2.1.1.2.1.3.1.2 0 .3-.1.4-.2.2-.2.1-.5-.1-.7 0 0-.3-.2-.3-.5s.2-.6.4-.8c.5-.5.7-1 .7-1.6-.1-.7-.7-1.2-.8-1.2-.3-.1-.6 0-.8.2-.2.2-.1.5.1.7 0 0 .3.2.3.5s-.2.6-.4.8c-.4.5-.6 1-.6 1.5z"/></g></svg>',
			'spa' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><path class="svg-color--primary" fill="{color}" d="M17 12.5c0 .3-.1.7-.2 1 2.8.6 4.2 1.7 4.2 2.5 0 1.2-3.5 3-9 3s-9-1.8-9-3c0-.8 1.5-1.8 4.2-2.5-.1-.3-.2-.6-.2-1-3 .7-5 2-5 3.5 0 2.2 4.5 4 10 4s10-1.8 10-4c0-1.5-2-2.8-5-3.5z"/><path class="svg-color--primary" fill="{color}" d="M8.2 13.3c0 .1 0 .1 0 0 0 .1.1.2.1.3.1.2.2.4.3.5.1.1.1.2.2.2.1.2.2.3.4.5 0 .2.1.2.2.3l.2.2c.1.1.2.1.3.2.2.1.4.2.7.3.1 0 .1 0 .2.1.1 0 .2 0 .3.1s.2 0 .3.1H12.8c.1 0 .2 0 .3-.1s.2 0 .3-.1c.1 0 .1 0 .2-.1.2-.1.5-.2.7-.3.1-.1.2-.1.3-.2.1 0 .1-.1.2-.2s.2-.1.2-.2c.2-.2.4-.4.6-.7.1-.1.1-.3.2-.4s.1-.3.2-.4c.1-.3.2-.6.2-1v-.3c0-.2-.1-1.3-1.2-2.6-1.3-1.8-1.9-2.8-1.9-2.8L12 5l-.9 1.5s-.6 1.1-1.9 2.9C8.1 10.8 8 11.8 8 12v.4c0 .3.1.6.2.9zM10 10c1.4-1.9 2-3 2-3s.6 1.1 2 3c1 1.2 1 2 1 2v.2c0 .8-.3 1.4-.7 1.9-.6.6-1.4.9-2.3.9s-1.7-.3-2.2-.9c-.5-.5-.8-1.1-.8-1.9V12s0-.8 1-2z"/><path class="svg-color--primary" fill="{color}" d="M5 16c0 .6 0 2 7 2s7-1.4 7-2c0-.4 0-1.2-2.5-1.7-.1.1-.1.3-.2.4l-.3.5-.1.1c1.3.2 2.1.5 2.1.8 0 .5-2.5 1-5.7 1H12c-3.3 0-6-.4-6-1 0-.3.8-.6 2.1-.8 0-.1-.1-.2-.1-.3-.1-.1-.2-.3-.2-.4-.1-.1-.1-.2-.2-.3C5 14.8 5 15.6 5 16z"/></svg>',
			'beach' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><g class="svg-color--primary" fill="{color}"><path d="M21.5 20h-1.7l-4.9-8.4 5.6-3.3-.5-.9C18.7 5.3 16.4 4 13.9 4c-1.2 0-2.2.3-3.2.8-.2.1-.3.2-.5.3-2 1.2-3.3 3.5-3.3 6 0 1.2.3 2.3.9 3.4l.5.9 5.6-3.3 4.6 7.9h-16c-.3 0-.5.2-.5.5s.2.5.5.5h19c.3 0 .5-.2.5-.5s-.2-.5-.5-.5zM13.9 5c2.2 0 4.2 1.2 5.2 2.9l-2.6 1.5c-1.5-2.6-3-3.8-4.1-4.2.5-.1 1-.2 1.5-.2zm-5.1 9c-.5-.9-.8-1.9-.8-2.9 0-1.7.6-3.2 1.7-4.3-.1 1.2.1 3 1.7 5.7L8.8 14zm3.4-2C9.9 8 10.9 6.1 11 5.8c.2 0 2.4.1 4.7 4.1L12.2 12zM4.5 7C5.9 7 7 5.9 7 4.5S5.9 2 4.5 2 2 3.1 2 4.5 3.1 7 4.5 7zm0-4C5.3 3 6 3.7 6 4.5S5.3 6 4.5 6 3 5.3 3 4.5 3.7 3 4.5 3z"/></g></svg>'/*,
			'favourite' => '<svg xmlns="http://www.w3.org/TR/SVG11" focusable="false" tabindex="-1" width="{size}" height="{size}" viewBox="0 0 {size} {size}"><path class="svg-color--secondary" d="M20.43 4.82A5.232 5.232 0 0 0 16.5 3 5.374 5.374 0 0 0 12 5.58 5.374 5.374 0 0 0 7.5 3a5.232 5.232 0 0 0-3.93 1.82 6.347 6.347 0 0 0-1.58 4.25c0 .01.01.05.01.06v.22c0 5.42 7.26 10.18 9.48 11.51a1.036 1.036 0 0 0 1.04 0C14.74 19.53 22 14.77 22 9.35v-.22c0-.01.01-.05.01-.06a6.347 6.347 0 0 0-1.58-4.25z" fill="#fff"/><path class="svg-color--primary" d="M21 9.18v.17c0 4.94-7.08 9.5-9 10.65-1.92-1.15-9-5.71-9-10.65v-.17a.41.41 0 0 0-.01-.11A4.816 4.816 0 0 1 7.5 4a4.39 4.39 0 0 1 3.66 2.12L12 7.44l.84-1.32A4.39 4.39 0 0 1 16.5 4a4.816 4.816 0 0 1 4.51 5.07.41.41 0 0 0-.01.11z" fill="{color}"/></svg>'*/
		);

		$out = $icon[ $key ];

		if ( $color != '' ) {
			$out = str_replace( '{color}', $color, $out );
		}

		if ( $size != '' ) {
			$out = str_replace( '{size}', $size, $out );
		}

		return $out;
	}
}

// ------------------------------------------------------------------------

if ( ! function_exists( 'queryHelper' ) ) {
	function queryHelper ( $conn, $function, $param = array(), $getQuery2 = 0 ) {
		//$getQuery2 = 1;
		global $countQueries, $getQuery;
		$getQueryFinal = ( $getQuery === 0 || $getQuery === 1 ) ? $getQuery : $getQuery2;
		$getQuery = $getQueryFinal;
		array_unshift( $param, $conn );

		if ( intval( $getQueryFinal ) === 1 ) {
			$param_tmp = $param;
			array_push( $param_tmp, 1 );
			printr( ( ++$countQueries ) . '<br />' . call_user_func_array( $function, $param_tmp ) . '<br />' );
		}

		if ( intval( $getQueryFinal ) !== 1 || $function == 'queryCount' || $function == 'querySequence' || $function == 'querySelect' ) {
			$data = call_user_func_array ( $function, $param );
			return $data;
		}
	}
}

// ------------------------------------------------------------------------

if ( ! function_exists( 'execQuery' ) ) {
	function execQuery ( $conn, $query ) {
		$resResorts = oci_parse( $conn, $query );
		oci_execute( $resResorts );
		return $resResorts;
	}
}

// ------------------------------------------------------------------------

if ( ! function_exists( 'querySelectOci' ) ) {
	function querySelectOci ( $conn, $qry, $getQuery = 0 ) {
		if ( $getQuery === 0 ) {
			return execQuery( $conn, $qry );
		} else {
			return $qry;
		}
	}
}

// ------------------------------------------------------------------------

if ( ! function_exists( 'queryCount' ) ) {
	function queryCount ( $conn, $table, $whereCond = "", $getQuery = 0 ) {
		$where = "";

		if ( $whereCond != "" ) {
			$where = "WHERE " . $whereCond;
		}

		$qry = "SELECT COUNT( * ) AS CNT FROM " . $table . " " . $where;

		if ( $getQuery === 0 ) {
			$res = execQuery( $conn, $qry );
			$row = oci_fetch_assoc( $res );

			return intval( $row['CNT'] );
		} else {
			return $qry;
		}
	}
}

// ------------------------------------------------------------------------

if ( ! function_exists( 'querySequence' ) ) {
	function querySequence ( $conn, $seqName, $getQuery = 0 ) {
		$qry = "SELECT " . $seqName . ".NEXTVAL AS SEQVAL FROM DUAL";

		if ( $getQuery === 0 ) {
			$res = execQuery( $conn, $qry );
			$row = oci_fetch_assoc( $res );

			return $row['SEQVAL'];
		} else {
			return $qry;
		}
	}
}

// ------------------------------------------------------------------------

if ( ! function_exists( 'querySelect' ) ) {
	function querySelect ( $conn, $table, $cols = '*', $whereCond = "", $orderByCol = "", $resStyle = "assoc", $getQuery = 0 ) {
		$where = "";
		$orderBy = "";

		if ( $whereCond != "" ) {
			$where = "WHERE " . $whereCond;
		}

		if ( $orderByCol != "" ) {
			$orderBy = "ORDER BY " . $orderByCol;
		}

		$qry = "SELECT " . $cols . " FROM " . $table . " " . $where . " " . $orderBy;

		if ( $getQuery === 0 ) {
			$res = execQuery( $conn, $qry );
			$i = 0;

			while ( $row = oci_fetch_assoc( $res ) ) {
				if ( !isset( $fields ) ) {
					$fields = array_keys( $row );
				}

				foreach ( $row as $key => $val ) {
					$rows[ $i ][ $key ] = $val;
				}

				$i++;
			}

			return array( 'fields' => $fields, 'rows' => $rows );
		} else {
			return $qry;
		}
	}
}

// ------------------------------------------------------------------------

if ( ! function_exists( 'queryInsert' ) ) {
	function queryInsert ( $conn, $table, $array, $getQuery = 0 ) {
		$cols = implode( ',', array_keys( $array ) );
		$vals = implode( ',', array_values( $array ) );

		$qry = "INSERT INTO " . $table . " ( " . $cols . " ) VALUES ( " . $vals . " )";

		if ( $getQuery === 0 ) {
			$res = execQuery( $conn, $qry );
		} else {
			return $qry;
		}
	}
}

// ------------------------------------------------------------------------

if ( ! function_exists( 'queryUpdate' ) ) {
	function queryUpdate ( $conn, $table, $cols, $whereCond = "", $getQuery = 0 ) {
		$where = "";

		if ( $whereCond != "" ) {
			$where = "WHERE " . $whereCond;
		}

		$qry = "UPDATE " . $table . " SET " . $cols . " " . $where;

		if ( $getQuery === 0 ) {
			$res = execQuery( $conn, $qry );
		} else {
			return $qry;
		}
	}
}

	if ( ! function_exists( 'querymyUpdate' ) ) {
	function querymyUpdate ( $conn, $table, $array, $whereCond, $getQuery = 0 ) {
		// print_r($array);exit;
		//$length = sizeof($array);

		for($i=0;$i<sizeof($array);$i++){
			$set [] = array_keys($array)[$i].'='.array_values($array)[$i];	
		}
		
		$cols = implode( ',',$set);
		
		// $vals = implode( ',', array_values( $array ) );

			$where = "WHERE " . $whereCond;
		
			 $qry = "UPDATE " . $table . " SET " . $cols . " " . $where;
		
		if ( $getQuery === 0 ) {
			$res = execQuery( $conn, $qry );
		} else {
			return $qry;
		}
	}
}

// ------------------------------------------------------------------------

if ( ! function_exists( 'queryDelete' ) ) {
	function queryDelete ( $conn, $table, $whereCond = "", $getQuery = 0 ) {
		$where = "";

		if ( $whereCond != "" ) {
			$where = "WHERE " . $whereCond;
		}

		$qry = "DELETE FROM " . $table . " " . $where;

		if ( $getQuery === 0 ) {
			$res = execQuery( $conn, $qry );
		} else {
			return $qry;
		}
	}
}
