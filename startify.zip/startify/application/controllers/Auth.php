<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Auth extends CI_Controller{

    
    public function __construct()
    {
        parent::__construct();
        $this->load->helper( array( 'url', 'html', 'file', 'form') );
		//
		//chk_session();
		$this->load->model('Ccdweb_model');
        $this->load->library('session','email');

        //Do your magic here
    }


    function shopify_call($token, $shop, $api_endpoint, $query = array(), $method = 'GET', $request_headers = array()) {
        
        // Build URL
        $url = "https://" . $shop . ".myshopify.com" . $api_endpoint;
        if (!is_null($query) && in_array($method, array('GET',  'DELETE'))) $url = $url . "?" . http_build_query($query);

        // Configure cURL
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, TRUE);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 3);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        // curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 3);
        // curl_setopt($curl, CURLOPT_SSLVERSION, 3);
        curl_setopt($curl, CURLOPT_USERAGENT, 'My New Shopify App v.1');
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);

        // Setup headers
        $request_headers[] = "";
        if (!is_null($token)) $request_headers[] = "X-Shopify-Access-Token: " . $token;
        curl_setopt($curl, CURLOPT_HTTPHEADER, $request_headers);

        if ($method != 'GET' && in_array($method, array('POST', 'PUT'))) {
            if (is_array($query)) $query = http_build_query($query);
            curl_setopt ($curl, CURLOPT_POSTFIELDS, $query);
        }
        
        // Send request to Shopify and capture any errors
        $response = curl_exec($curl);
        $error_number = curl_errno($curl);
        $error_message = curl_error($curl);

        // Close cURL to be nice
        curl_close($curl);

        // Return an error is cURL has a problem
        if ($error_number) {
            return $error_message;
        } else {

            // No error, return Shopify's response by parsing out the body and the headers
            $response = preg_split("/\r\n\r\n|\n\n|\r\r/", $response, 2);

            // Convert headers into an array
            $headers = array();
            $header_data = explode("\n",$response[0]);
            $headers['status'] = $header_data[0]; // Does not contain a key, have to explicitly set
            array_shift($header_data); // Remove status, we've already set it above
            foreach($header_data as $part) {
                $h = explode(":", $part);
                $headers[trim($h[0])] = trim($h[1]);
            }

            // Return headers and Shopify's response
            return array('headers' => $headers, 'response' => $response[1]);

        }
        
    }
    
    public function edit_ticket(){
        //echo "<pre>";print_r($_POST);die;
        $ticket_id = $_GET['order_id'];
        $whereid = array('Id' => $ticket_id);
        $ticketresults = $this->Ccdweb_model->getalldata('return_order',$whereid,null,'*',null,null,null);
        //echo "<pre>";print_r($ticketresults);die;
        
        if(isset($_POST['action']) && $_POST['action'] == 'saveform')
        {

            $this->load->library('form_validation');
            $this->form_validation->set_rules('name','User name','required'); 
            $this->form_validation->set_rules('email','email','required'); 
            
            $id = $_POST['id'];
            $name = $_POST['name'];
            $email = $_POST['email'];
            $phoneNumber = $_POST['phoneNumber'];
            $orderNumber = $_POST['orderNumber'];
            $returnBankDetail = $_POST['returnBankDetail'];
            $reason = $_POST['reason'];
            $return_order_data = array('Name'=>$name,'Email'=>$email,'PhoneNumber'=>$phoneNumber,'OrderNumber'=>$orderNumber,'ReturnBankdetail'=>$returnBankDetail,'Reason'=>$reason);
            $whereid1 = array('Id' => $id);
        
            $res = $this->Ccdweb_model->update('return_order',$whereid1,$return_order_data,null);


           if($res == 1)
            {
                            $this->load->library('email');
                            $to = "raj.perception@gmail.com";
                            $from = 'raj.perception@gmail.com';
                            $subject = "Return ticket detail";
                            $message = "Ticket detail<br>"."Name: ".$name."<br>"."Email: ".$email."<br>"."Phone Number: ".$phoneNumber."<br>"."Order Number: ".$orderNumber."<br>"."Return Bank Detail: ".$returnBankDetail."<br>"."Reason: ".$reason."<br>"."Ticket Number: ".$ticketresults[0]['TicketNumber'];
                            
                            $config = array(
                                'protocol'  => 'smtp',
                                'smtp_host' => 'ssl://smtp.googlemail.com',
                                'smtp_port' => 465,
                                'smtp_user' => 'raj.perception@gmail.com',
                                'smtp_pass' => 'A1G915now!',
                                'mailtype'  => 'html',
                                'charset'   => 'utf-8',
                                
                            );
                            $this->email->initialize($config);
        
                            $this->email->set_newline("\r\n");
                            $this->email->from($from);
                            $this->email->to($to);
                            $this->email->subject($subject);
                            $this->email->message($message);

                            if ($this->email->send()) 
                            {
                                //echo 'Email has been sent successfully';
                            } 
                            else 
                            {
                                show_error($this->email->print_debugger());
                            }

                $values['message'] = 'success';
                $successresult =  json_encode($values);
                echo $successresult;exit;
            
            }
            else
            {
                $values['message'] = 'FAIL';
                $successresult =  json_encode($values);
                echo $successresult;exit;
            }
        }

        $data = array();   
        $data['ticketresults']=$ticketresults;    
        $this->load->view('edit_ticket',$data);
    
    }

    public function login(){
    	//echo "<pre>";print_r($_POST);die;
    	//die("hello");
    	$this->load->library('form_validation');
		$username = $this->input->post('UserName');
        $Password = $this->input->post('Password');
        if (!isset($username) || $username == '' || $username == 'undefined') {
            /*If Username that we recieved is invalid, go here, and return 2 as output*/
            redirect('https://ipl2019.myshopify.com/pages/login/?message=fial'); 

            //echo 2;
            //exit();
        }
        if (!isset($Password) || $Password == '' || $Password == 'undefined') {
            /*If Password that we recieved is invalid, go here, and return 3 as output*/
             redirect('https://ipl2019.myshopify.com/pages/login/?message=fial'); 

            //echo 3;
            //exit();
        }
        $this->form_validation->set_rules('UserName', 'UserName', 'required');
        $this->form_validation->set_rules('Password', 'Password', 'required');
        if ($this->form_validation->run() == FALSE) {
            /*If Both Username &  Password that we recieved is invalid, go here, and return 4 as output*/
            //echo 4;
            //exit();
            redirect('https://ipl2019.myshopify.com/pages/login/?message=fial'); 

        } else {
            /*Create object of model MLogin.php file under models folder*/
            /*validate($username, $Password) is the function in Mlogin.php*/
            $result = $this->Ccdweb_model->validate($username, $Password);
            if (count($result) == 1) {
                /*If everything is fine, then go here, and return 1 as output and set session*/
                $data = array(
                    'idUser' => $result[0]->id,
                    'username' => $result[0]->username
                );
                $this->session->set_userdata('login', $data);
                //echo 1;
                 redirect('https://ipl2019.myshopify.com/pages/login/?message=success'); 

            } else {
                /*If Both Username &  Password that we recieved is invalid, go here, and return 5 as output*/
                redirect('https://ipl2019.myshopify.com/pages/login/?message=fial'); 

               // $values['result'] = '5';
				//echo json_encode($values);exit;

				//echo 5;exit;
            }
        }

  	}

    public function ticket_detail(){
        $order_id = $_GET['order_id'];
        $whereid = array('Id' => $order_id);

        $results = $this->Ccdweb_model->getalldata('return_order',$whereid,null,'*',null,null,null);

        //echo "<pre>";print_r($results);die;
        
        $shop = "ipl2019";
        $token = "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";
        $query = array(
            "Content-type" => "application/json" // Tell Shopify that we're expecting a response in JSON format
        );
        $array = array();
        $new_ordeid = $results[0]['OrderNumber'];
        //GET /admin/api/2021-04/orders/450789469.json
        $orders = $this->shopify_call($token, $shop, "/admin/api/2021-04/orders/".$new_ordeid.".json", $array, 'GET');
        $orders = json_decode($orders['response'], JSON_PRETTY_PRINT);
        // Run API call to get products
        //echo "<pre>";print_r();die;
        //echo "<pre>";print_r($orders);die;
        
        $real_orderid = '';
        if(isset($orders['order']['id']) && $orders['order']['id'] != '')
        {
          $real_orderid = $orders['order']['id'];
        }
                        
        
        $data['ticket_detail'] = $results;
        $order_status = $this->Ccdweb_model->getalldata('order_status',null,null,'*',null,null,null);
            $data['order_status'] = $order_status;
        

        $ticketid = $results[0]['TicketNumber'];
        $whereidtick = array('TicketId' => $ticketid);
        $order_by = "Id DESC";
        $ticket_comment = $this->Ccdweb_model->getalldata('ticket_comments',$whereidtick,null,'*',null,$order_by,null);
        $data['ticket_comment'] = $ticket_comment;
            
        $data['real_orderid'] = $real_orderid;
        $data['orders'] = $orders;


            //echo "<pre>";print_r($data);die;
        $this->load->view('ticket_detail',$data);
    }    

    public function chnage_status(){
        //echo "<pre>";print_r($_POST);die;
        if(isset($_POST['action']) && $_POST['action'] == 'change_status')
        {            

                    $order_id = $_POST['order_id'];
                        
                    $whereid = array('Id' => $order_id);

                    $results = $this->Ccdweb_model->getalldata('return_order',$whereid,null,'*',null,null,null);

                    //echo "<pre>";print_r($results[0][]);die;
        
                    if(!empty($results))
                    {
                        $status = $_POST['status'];
                        $comment = $_POST['comment'];
                        $TicketNumber = $results[0]['TicketNumber'];
                        $username = $results[0]['Name'];
                        
                        $statusData = array('Status'=>$status);
                        $where = array('Id' => $order_id);

                        $res = $this->Ccdweb_model->update('return_order',$where,$statusData,null);

                        $commentData = array('Comment'=>$comment,'TicketId'=>$TicketNumber,'Username'=>$username);
                        $this->Ccdweb_model->insertdata('ticket_comments',$commentData);



                        if($status == '1'){
                                $new_status= "New";
                            }
                            else if($status == '2'){
                                $new_status= "Return Inprocess";
                            }
                            else if($status == '3'){
                                $new_status= "Return Done";
                            }
                            else if($status == '4'){
                                $new_status= "Closed";
                            }
                            else if($status == '5'){
                                $new_status= "Invalid";
                            }

                        if($res == 1)
                        {
                            //die("hell");
                            //$this->load->config('email');
                            $this->load->library('email');
                            $to = $results[0]['Email'];
                            $from = 'raj.perception@gmail.com';
                            $subject = "Ticket Status";
                            $message = "Your ticket status<br>"."Ticket Number: ".$results[0]['TicketNumber']."<br>"."Ticket status: ".$new_status."<br>"."Comment: ".$comment;
                            $config = array(
                                'protocol'  => 'smtp',
                                'smtp_host' => 'ssl://smtp.googlemail.com',
                                'smtp_port' => 465,
                                'smtp_user' => 'raj.perception@gmail.com',
                                'smtp_pass' => 'A1G915now!',
                                'mailtype'  => 'html',
                                'charset'   => 'utf-8',
                                
                            );
                            $this->email->initialize($config);
        
                            $this->email->set_newline("\r\n");
                            $this->email->from($from);
                            $this->email->to($to);
                            $this->email->subject($subject);
                            $this->email->message($message);

                            if ($this->email->send()) 
                            {
                                //echo 'Email has been sent successfully';
                            } 
                            else 
                            {
                                show_error($this->email->print_debugger());
                            }
                     
                            //$this->Ccdweb_model->sendMail($to,$fromemail,$subject,$message);
                            //$this->Ccdweb_model->sendMail1();

                            $values['message'] = 'success';
                            $successresult =  json_encode($values);
                            echo $successresult;exit;
                        }
                        else
                        {
                            $values['message'] = 'fial';
                            $successresult =  json_encode($values);
                            echo $successresult;exit;
                        }
                    }
                    else
                    {
                        $values['message'] = 'order_id_fail';
                        $successresult =  json_encode($values);
                        echo $successresult;exit;
                        
                    }
            
                       
        }
    }
    
    public function order_control(){
        //echo "<pre>";print_r($_FILES);die;
    	if(isset($_POST['action']) && $_POST['action'] == 'saveform')
    	{

    		$this->load->library('form_validation');
		    $this->form_validation->set_rules('name','User name','required'); 
			$this->form_validation->set_rules('email','email','required'); 
		
    		$name = $_POST['name'];
    		$email = $_POST['email'];
            $phoneNumber = $_POST['phoneNumber'];
            $orderNumber = $_POST['orderNumber'];
            $returnBankDetail = $_POST['returnBankDetail'];
            $reason = $_POST['reason'];
            $doc = '';
            
            if(isset($_FILES['doc']) && $_FILES['doc']['name'] != '')
                {
                    $doc = $_FILES['doc']['name'];

                          $errors= array();
                          $file_name = $_FILES['doc']['name'];
                          $file_size =$_FILES['doc']['size'];
                          $file_tmp =$_FILES['doc']['tmp_name'];
                          $file_type=$_FILES['doc']['type'];
                          $file_ext=strtolower(end(explode('.',$_FILES['doc']['name'])));
                          
                          $extensions= array("jpeg","jpg","png","gif");
                          
                          if(in_array($file_ext,$extensions)=== false){
                             $errors[]="extension not allowed, please choose a JPEG or PNG file.";
                          }
                          
                          if($file_size > 2097152){
                             $errors[]='File size must be excately 2 MB';
                          }
                          
                          if(empty($errors)==true){
                             move_uploaded_file($file_tmp,"./uploads/document/".$file_name);
                             echo "Success";
                          }else{
                             print_r($errors);
                          }

                }
            


            
            $digits = 5;
            $TicketNumber =  rand(pow(10, $digits-1), pow(10, $digits)-1);
            
            $whereidt = array('TicketNumber' => $TicketNumber);

            $results = $this->Ccdweb_model->getalldata('return_order',$whereidt,null,'*',null,null,null);

            if(!empty($results))
            {
                $TicketNumber_valid = $TicketNumber;
            }
            else
            {
                $TicketNumber =  rand(pow(10, $digits-1), pow(10, $digits)-1);
                $TicketNumber_valid = $TicketNumber;
            }

    		$return_order_data = array('Name'=>$name,'Email'=>$email,'PhoneNumber'=>$phoneNumber,'OrderNumber'=>$orderNumber,'ReturnBankdetail'=>$returnBankDetail,'Reason'=>$reason,'Document'=>$doc,'TicketNumber'=>$TicketNumber_valid,'Status'=>1);
			$res = $this->Ccdweb_model->insertdata('return_order',$return_order_data);

		   if($res == 1)
			{
                            $this->load->library('email');
                            $to = "raj.perception@gmail.com";
                            $from = 'raj.perception@gmail.com';
                            $subject = "Return ticket detail";
                            $message = "Ticket detail<br>"."Name: ".$name."<br>"."Email: ".$email."<br>"."Phone Number: ".$phoneNumber."<br>"."Order Number: ".$orderNumber."<br>"."Return Bank Detail: ".$returnBankDetail."<br>"."Reason: ".$reason."<br>"."Ticket Number: ".$TicketNumber_valid;
                            
                            $config = array(
                                'protocol'  => 'smtp',
                                'smtp_host' => 'ssl://smtp.googlemail.com',
                                'smtp_port' => 465,
                                'smtp_user' => 'raj.perception@gmail.com',
                                'smtp_pass' => 'A1G915now!',
                                'mailtype'  => 'html',
                                'charset'   => 'utf-8',
                                
                            );
                            $this->email->initialize($config);
        
                            $this->email->set_newline("\r\n");
                            $this->email->from($from);
                            $this->email->to($to);
                            $this->email->subject($subject);
                            $this->email->message($message);

                            if ($this->email->send()) 
                            {
                                echo 'Email has been sent successfully';
                            } 
                            else 
                            {
                                show_error($this->email->print_debugger());
                            }

                            $to1 = $email;
                            $from1 = 'raj.perception@gmail.com';
                            $subject1 = $reason;
                            $message1 = "Hello ".$name."<br><br>Thank you for reaching out to us. We are working on your issue (Ticket ID: ".$TicketNumber_valid.") and will get back to you soon. Please let us know if you have any more questions. We will be happy to help.<br><br><br>Thanks,<br>Agent Name<br>Perception system";

                            
                            $config1 = array(
                                'protocol'  => 'smtp',
                                'smtp_host' => 'ssl://smtp.googlemail.com',
                                'smtp_port' => 465,
                                'smtp_user' => 'raj.perception@gmail.com',
                                'smtp_pass' => 'A1G915now!',
                                'mailtype'  => 'html',
                                'charset'   => 'utf-8',
                                
                            );
                            $this->email->initialize($config1);
        
                            $this->email->set_newline("\r\n");
                            $this->email->from($from1);
                            $this->email->to($to1);
                            $this->email->subject($subject1);
                            $this->email->message($message1);

                            if ($this->email->send()) 
                            {
                                echo 'Email has been sent successfully';
                            } 
                            else 
                            {
                                show_error($this->email->print_debugger());
                            }



				redirect('https://ipl2019.myshopify.com/pages/order_return?message=success'); 

			}
			else
			{
				$values['message'] = 'FAIL';
				$successresult =  json_encode($values);
				echo $successresult;exit;
			}
    	}

    	
    }

    public function order_listing(){
        $shop = 'ipl2019.myshopify.com/';
        if(isset($shop)){
            $this->session->set_userdata($shop);
        }

        if(($this->session->userdata('access_token'))){
            $data = array(
                'api_key' => $this->config->item('shopify_api_key'),
                'shop' => $shop
            );

            $results = $this->Ccdweb_model->getalldata('return_order',null,null,'*',null,null,null);
            $data['results'] = $results;
            $order_status = $this->Ccdweb_model->getalldata('order_status',null,null,'*',null,null,null);
            $data['order_status'] = $order_status;
            
            //echo "<pre>";print_r($data);die;

            $total_ticket = $this->Ccdweb_model->total_ticket_data();
            $data['total_ticket'] = $total_ticket;
            
            $open_one = $this->Ccdweb_model->weekly_data('1','1');
            $open_two = $this->Ccdweb_model->weekly_data('1','2');
            $open_three = $this->Ccdweb_model->weekly_data('1','3');
            $open_four = $this->Ccdweb_model->weekly_data('1','4');
            $open_five = $this->Ccdweb_model->weekly_data('1','5');
            $open_sixe = $this->Ccdweb_model->weekly_data('1','6');
            $open_saven = $this->Ccdweb_model->weekly_data('1','7');
            $data['open_one'] = $open_one;
            $data['open_two'] = $open_two;
            $data['open_three'] = $open_three;
            $data['open_four'] = $open_four;
            $data['open_five'] = $open_five;
            $data['open_sixe'] = $open_sixe;
            $data['open_saven'] = $open_saven;


            $return_inprocess_one = $this->Ccdweb_model->weekly_data('2','1');
            $return_inprocess_two = $this->Ccdweb_model->weekly_data('2','2');
            $return_inprocess_three = $this->Ccdweb_model->weekly_data('2','3');
            $return_inprocess_four = $this->Ccdweb_model->weekly_data('2','4');
            $return_inprocess_five = $this->Ccdweb_model->weekly_data('2','5');
            $return_inprocess_sixe = $this->Ccdweb_model->weekly_data('2','6');
            $return_inprocess_saven = $this->Ccdweb_model->weekly_data('2','7');

            $data['return_inprocess_one'] = $return_inprocess_one;
            $data['return_inprocess_two'] = $return_inprocess_two;
            $data['return_inprocess_three'] = $return_inprocess_three;
            $data['return_inprocess_four'] = $return_inprocess_four;
            $data['return_inprocess_five'] = $return_inprocess_five;
            $data['return_inprocess_sixe'] = $return_inprocess_sixe;
            $data['return_inprocess_saven'] = $return_inprocess_saven;

            
            $return_done_one = $this->Ccdweb_model->weekly_data('3','1');
            $return_done_two = $this->Ccdweb_model->weekly_data('3','2');
            $return_done_three = $this->Ccdweb_model->weekly_data('3','3');
            $return_done_four = $this->Ccdweb_model->weekly_data('3','4');
            $return_done_five = $this->Ccdweb_model->weekly_data('3','5');
            $return_done_sixe = $this->Ccdweb_model->weekly_data('3','6');
            $return_done_saven= $this->Ccdweb_model->weekly_data('3','7');
            
            $data['return_done_one'] = $return_done_one;
            $data['return_done_two'] = $return_done_two;
            $data['return_done_three'] = $return_done_three;
            $data['return_done_four'] = $return_done_four;
            $data['return_done_five'] = $return_done_five;
            $data['return_done_sixe'] = $return_done_sixe;
            $data['return_done_saven'] = $return_done_saven;


            $closed_one = $this->Ccdweb_model->weekly_data('4','1');
            $closed_two = $this->Ccdweb_model->weekly_data('4','2');
            $closed_three = $this->Ccdweb_model->weekly_data('4','3');
            $closed_four = $this->Ccdweb_model->weekly_data('4','4');
            $closed_five = $this->Ccdweb_model->weekly_data('4','5');
            $closed_sixe = $this->Ccdweb_model->weekly_data('4','6');
            $closed_saven = $this->Ccdweb_model->weekly_data('4','7');
            $data['closed_one'] = $closed_one;
            $data['closed_two'] = $closed_two;
            $data['closed_three'] = $closed_three;
            $data['closed_four'] = $closed_four;
            $data['closed_five'] = $closed_five;
            $data['closed_sixe'] = $closed_sixe;
            $data['closed_saven'] = $closed_saven;


            $invalid_one = $this->Ccdweb_model->weekly_data('5','1');
            $invalid_two = $this->Ccdweb_model->weekly_data('5','2');
            $invalid_three = $this->Ccdweb_model->weekly_data('5','3');
            $invalid_four = $this->Ccdweb_model->weekly_data('5','4');
            $invalid_five = $this->Ccdweb_model->weekly_data('5','5');
            $invalid_sixe = $this->Ccdweb_model->weekly_data('5','6');
            $invalid_saven = $this->Ccdweb_model->weekly_data('5','7');
            $data['invalid_one'] = $invalid_one;
            $data['invalid_two'] = $invalid_two;
            $data['invalid_three'] = $invalid_three;
            $data['invalid_four'] = $invalid_four;
            $data['invalid_five'] = $invalid_five;
            $data['invalid_sixe'] = $invalid_sixe;
            $data['invalid_saven'] = $invalid_saven;

            //echo "<pre>";print_r($open_two);die;

            $open = $this->Ccdweb_model->weeklyall_data('1');
            $return_inprocess = $this->Ccdweb_model->weeklyall_data('2');
            $return_done = $this->Ccdweb_model->weeklyall_data('3',);
            $closed = $this->Ccdweb_model->weeklyall_data('4');
            $invalid = $this->Ccdweb_model->weeklyall_data('5');

            $data['open'] = $open;
            $data['return_inprocess'] = $return_inprocess;
            $data['return_done'] = $return_done;
            $data['closed'] = $closed;
            $data['invalid'] = $invalid;

            
            $this->load->view('ticket_listing',$data);
        }
        else{
            $this->auth($shop);
        }
    }

    public function auth($shop){

    	//auth/access
    	//auth/authCallback
        $data = array(
            'API_KEY' => $this->config->item('shopify_api_key'),
            'API_SECRET' => $this->config->item('shopify_secret'),
            'SHOP_DOMAIN' => $shop,
            'ACCESS_TOKEN' => ''
        );
        $this->load->library('Shopify' , $data); //load shopify library and pass values in constructor

        $scopes = array('read_orders','write_orders'); //what app can do
        $redirect_url = $this->config->item('redirect_url'); //redirect url specified in app setting at shopify
        $paramsforInstallURL = array(
            'scopes' => $scopes,
            'redirect' => $redirect_url
        );

        $permission_url = $this->shopify->installURL($paramsforInstallURL);
         
        $this->load->view('auth/escapeIframe', ['installUrl' => $permission_url]);
        
    }

    public function authCallback(){
        $code = $this->input->get('code');
        //$shop = $this->input->get('shop');
        $shop = 'ipl2019.myshopify.com/';


        if(isset($code)){
            $data = array(
            'API_KEY' => $this->config->item('shopify_api_key'),
            'API_SECRET' => $this->config->item('shopify_secret'),
            'SHOP_DOMAIN' => $shop,
            'ACCESS_TOKEN' => ''
        );
            $this->load->library('Shopify' , $data); //load shopify library and pass values in constructor
        }

        $accessToken = $this->shopify->getAccessToken($code);

        $Access_tokendata = array('Access_token'=>$accessToken);
                        $this->Ccdweb_model->insertdata('genrate_access_token',$Access_tokendata);

        //echo $accessToken;die;
        $this->session->set_userdata(['shop' => $shop , 'access_token' => $accessToken]);

        redirect('https://'.$shop.'/admin/apps');
    }

    

}

 